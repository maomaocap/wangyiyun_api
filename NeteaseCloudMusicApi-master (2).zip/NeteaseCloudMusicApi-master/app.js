#!/usr/bin/env node
require('./server').serveNcmApi({
  checkVersion: true,
})
